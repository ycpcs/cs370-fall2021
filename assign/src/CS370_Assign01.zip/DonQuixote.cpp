// CS370 Assignment 1 - Don Quixote
// Fall 2021

#include <stdio.h>
#include "../common/vgl.h"
#include "../common/utils.h"
#include "../common/vmath.h"

using namespace vmath;

// Vertex array and buffer names
enum VAO_IDs {Square, Triangle, Sun, NumVAOs};
enum Obj_Buffer_IDs {PosBuffer, IndexBuffer, NumObjBuffers};
enum Color_Buffer_IDs {BlueSky, GreenGrass, BrownHouse, RedRoof, BlueFan, YellowSun, NumColorBuffers};

// Vertex array and buffer objects
GLuint VAOs[NumVAOs];
GLuint ObjBuffers[NumVAOs][NumObjBuffers];
GLuint ColorBuffers[NumColorBuffers];

// Number of indices in each object
GLint numIndices[NumVAOs];

// Number of component coordinates
GLint posCoords = 2;
GLint colCoords = 4;

// Shader variables
// Shader program reference
GLuint trans_program;
// Shader component references
GLuint trans_vPos;
GLuint trans_vCol;
GLuint trans_model_mat_loc;
// Shader source files
const char *trans_vertex_shader = "../trans.vert";
const char *trans_frag_shader = "../trans.frag";

void display( );
void render_scene( );
void build_geometry( );
void key_callback(GLFWwindow *window, int key, int scancode, int action, int mods);
void mouse_callback(GLFWwindow *window, int button, int action, int mods);

int main(int argc, char**argv)
{
	// Create OpenGL window
	GLFWwindow* window = CreateWindow("Don Quixote - Assignment 1");
    if (!window) {
        fprintf(stderr, "ERROR: could not open window with GLFW3\n");
        glfwTerminate();
        return 1;
    } else {
        printf("OpenGL window successfully created\n");
    }

    // TODO: Register callbacks

	// Create geometry buffers
    build_geometry();
    
    // Load shaders and associate shader variables
	ShaderInfo trans_shaders[] = { {GL_VERTEX_SHADER, trans_vertex_shader},{GL_FRAGMENT_SHADER, trans_frag_shader},{GL_NONE, NULL} };
	trans_program = LoadShaders(trans_shaders);
	trans_vPos = glGetAttribLocation(trans_program, "vPosition");
    trans_vCol = glGetAttribLocation(trans_program, "vColor");
    trans_model_mat_loc = glGetUniformLocation(trans_program, "model_matrix");

	// Start loop
    while ( !glfwWindowShouldClose( window ) ) {
    	// Draw graphics
        display();
        // Update other events like input handling
        glfwPollEvents();
        //  TODO: Update angle based on time for fixed rpm when animating

        // Swap buffer onto screen
        glfwSwapBuffers( window );
    }

    // Close window
    glfwTerminate();
    return 0;
}

void display( )
{
	// Clear window
	glClear(GL_COLOR_BUFFER_BIT);

    // Render objects
	render_scene();

	// Flush pipeline
	glFlush();
}

void render_scene( ) {
    // TODO: Declare transformation matrices

    // Select shader program
    glUseProgram(trans_program);

    // Draw squares
    glBindVertexArray(VAOs[Square]);
    glBindBuffer(GL_ARRAY_BUFFER, ObjBuffers[Square][PosBuffer]);
    glVertexAttribPointer(trans_vPos, posCoords, GL_FLOAT, GL_FALSE, 0, NULL);
    glEnableVertexAttribArray(trans_vPos);

    // TODO: Draw sky

    // TODO: Draw grass

    // TODO: Draw house

    // Draw triangles
    glBindVertexArray(VAOs[Triangle]);
    glBindBuffer(GL_ARRAY_BUFFER, ObjBuffers[Triangle][PosBuffer]);
    glVertexAttribPointer(trans_vPos, posCoords, GL_FLOAT, GL_FALSE, 0, NULL);
    glEnableVertexAttribArray(trans_vPos);

    // TODO: Draw roof

    // TODO: Draw fan

    // TODO: Draw sun (using triangle fan)
    glBindVertexArray(VAOs[Sun]);
    glBindBuffer(GL_ARRAY_BUFFER, ObjBuffers[Sun][PosBuffer]);
    glVertexAttribPointer(trans_vPos, posCoords, GL_FLOAT, GL_FALSE, 0, NULL);
    glEnableVertexAttribArray(trans_vPos);

}

void build_geometry( )
{
    // Generate vertex arrays
	glGenVertexArrays(NumVAOs, VAOs);
	glGenBuffers(NumObjBuffers, ObjBuffers[Square]);
	glGenBuffers(NumObjBuffers, ObjBuffers[Triangle]);
	glGenBuffers(NumObjBuffers, ObjBuffers[Sun]);
    glGenBuffers(NumColorBuffers, ColorBuffers);

	// Bind square
	glBindVertexArray(VAOs[Square]);

    // TODO: Define square vertices
    GLfloat sqVertices[][2] = {
            { 1.0f, 1.0f},
            {-1.0f, 1.0f},
            {-1.0f,-1.0f},
            { 1.0f,-1.0f},
    };

    // TODO: Define blue sky color
    // TODO: Define green grass color
    // TODO: Define brown house color

    // TODO: Define square face indices (ensure proper orientation)

	// TODO: Set square numIndices

    // TODO: Bind square vertex positions

	// TODO: Bind blue sky

	// TODO: Bind green grass

	// TODO: Bind brown house

    // TODO: Bind square indices


	// Bind triangle
	glBindVertexArray(VAOs[Triangle]);

    // Define triangle vertices
    GLfloat triVertices[][2] = {
            { 1.0f, 1.0f},
            {-1.0f, 1.0f},
            {-1.0f,-1.0f},
    };

    // TODO: Define red roof color

    // TODO: Define blue fan color

    // TODO: Define triangle indices (ensure proper orientation)

	// TODO: Set triangle numIndices

    // TODO: Bind triangle vertex positions

	// TODO: Bind red roof color

    // TODO: Bind blue fan color

    // TODO: Bind triangle indices
    
    // Bind sun
    glBindVertexArray(VAOs[Sun]);

    // TODO: Define sun vertices and colors

	// TODO: Set sun numIndices

    // TODO: Bind sun vertices

    // TODO: Bind sun colors
    
    // TODO: Bind sun indices

}

void key_callback(GLFWwindow *window, int key, int scancode, int action, int mods) {
    // Esc closes window
    if (key == GLFW_KEY_ESCAPE) {
        glfwSetWindowShouldClose(window, true);
    }

    // TODO: Start/Stop animation with spacebar

}

void mouse_callback(GLFWwindow *window, int button, int action, int mods){
    // TODO: Flip spin direction with mouse click

}

