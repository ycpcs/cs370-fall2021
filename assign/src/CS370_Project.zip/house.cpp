// CS370 Final Project
// Fall 2021

#define STB_IMAGE_IMPLEMENTATION
#include "../common/stb_image.h"	// Sean Barrett's image loader - http://nothings.org/
#include <stdio.h>
#include <vector>
#include "../common/vgl.h"
#include "../common/objloader.h"
#include "../common/utils.h"
#include "../common/vmath.h"
#include "lighting.h"
#define DEG2RAD (M_PI/180.0)

using namespace vmath;
using namespace std;

enum VAO_IDs {Cube, NumVAOs};
enum ObjBuffer_IDs {PosBuffer, NormBuffer, TexBuffer, NumObjBuffers};
enum Color_Buffer_IDs {RedCube, NumColorBuffers};
enum LightBuffer_IDs {LightBuffer, NumLightBuffers};
enum MaterialBuffer_IDs {MaterialBuffer, NumMaterialBuffers};
enum MaterialNames {};
enum Textures {NumTextures};

GLuint VAOs[NumVAOs];
GLuint ObjBuffers[NumVAOs][NumObjBuffers];
GLuint ColorBuffers[NumColorBuffers];
GLuint LightBuffers[NumLightBuffers];
GLuint MaterialBuffers[NumMaterialBuffers];
GLuint TextureIDs[NumTextures];

GLint numVertices[NumVAOs];
GLint posCoords = 4;
GLint colCoords = 4;
GLint normCoords = 3;
GLint texCoords = 2;

// Model files
vector<const char *> objFiles = {"../models/cube.obj"};

// Camera
vec3 eye = {3.0f, 0.0f, 0.0f};
vec3 center = {0.0f, 0.0f, 0.0f};
vec3 up = {0.0f, 1.0f, 0.0f};
GLfloat azimuth = 0.0f;
GLfloat daz = 2.0f;
GLfloat elevation = 90.0f;
GLfloat del = 2.0f;
GLfloat radius = 2.0f;
GLfloat dr = 0.1f;

// Shader variables
// Shader program reference - solid color objects
GLuint col_mesh_program;
// Shader component references
GLuint col_mesh_vPos;
GLuint col_mesh_vCol;
GLuint col_mesh_model_mat_loc;
GLuint col_mesh_proj_mat_loc;
GLuint col_mesh_cam_mat_loc;
const char *color_vertex_shader = "../color_mesh.vert";
const char *color_frag_shader = "../color_mesh.frag";

// Shader variables
// Shader program reference - lighting objects
GLuint gouraud_program;
// Shader component references
GLuint gouraud_vPos;
GLuint gouraud_vNorm;
GLuint gouraud_camera_mat_loc;
GLuint gouraud_model_mat_loc;
GLuint gouraud_proj_mat_loc;
GLuint gouraud_norm_mat_loc;
GLuint gouraud_lights_block_idx;
GLuint gouraud_materials_block_idx;
GLuint gouraud_material_loc;
GLuint gouraud_eye_loc;
const char *light_vertex_shader = "../gouraud.vert";
const char *light_frag_shader = "../gouraud.frag";

// Shader variables
// Shader program reference - texture objects
GLuint basic_tex_program;
GLuint basic_tex_vPos;
GLuint basic_tex_vTex;
GLuint basic_tex_camera_mat_loc;
GLuint basic_tex_model_mat_loc;
GLuint basic_tex_proj_mat_loc;
GLuint basic_tex_eye_loc;
const char *tex_vertex_shader = "../basicTex.vert";
const char *tex_frag_shader = "../basicTex.frag";

// Global state
mat4 proj_matrix;
mat4 camera_matrix;
mat4 model_matrix;
mat4 normal_matrix;

// Global screen dimensions
GLint ww,hh;

void display();
void render_scene();
void build_geometry();
void build_color_buffer(GLuint obj, vec4 color, GLuint buffer);
void load_color_object(GLuint obj);
void draw_color_obj(GLuint obj, GLuint color);
void build_materials();
void build_lights();
void load_mat_object(GLuint obj);
void draw_mat_object(GLuint obj);
void build_textures();
void load_tex_object(GLuint obj);
void draw_tex_object(GLuint obj);
void framebuffer_size_callback(GLFWwindow *window, int width, int height);
void key_callback(GLFWwindow *window, int key, int scancode, int action, int mods);
void mouse_callback(GLFWwindow *window, int button, int action, int mods);

int main(int argc, char**argv)
{
	// Create OpenGL window
	GLFWwindow* window = CreateWindow("Think Inside The Box");
    if (!window) {
        fprintf(stderr, "ERROR: could not open window with GLFW3\n");
        glfwTerminate();
        return 1;
    } else {
        printf("OpenGL window successfully created\n");
    }

    // Store initial window size
    glfwGetFramebufferSize(window, &ww, &hh);

    // Register callbacks
    glfwSetFramebufferSizeCallback(window, framebuffer_size_callback);
    glfwSetKeyCallback(window,key_callback);
    glfwSetMouseButtonCallback(window, mouse_callback);

	// Create geometry buffers
    build_geometry();
    // Create light buffers
    build_lights();
    // Create material buffers
    build_materials();
    // Create textures
    build_textures();
    
    // Load shaders and associate shader variables - color shader
	ShaderInfo color_shaders[] = { {GL_VERTEX_SHADER, color_vertex_shader},{GL_FRAGMENT_SHADER, color_frag_shader},{GL_NONE, NULL} };
	col_mesh_program = LoadShaders(color_shaders);
    col_mesh_vPos = glGetAttribLocation(col_mesh_program, "vPosition");
    col_mesh_vCol = glGetAttribLocation(col_mesh_program, "vColor");
    col_mesh_model_mat_loc = glGetUniformLocation(col_mesh_program, "model_matrix");
    col_mesh_proj_mat_loc = glGetUniformLocation(col_mesh_program, "proj_matrix");
    col_mesh_cam_mat_loc = glGetUniformLocation(col_mesh_program, "camera_matrix");

    // Load shaders and associate shader variables - lighting shader
	ShaderInfo gouraud_shaders[] = { {GL_VERTEX_SHADER, light_vertex_shader},{GL_FRAGMENT_SHADER, light_frag_shader},{GL_NONE, NULL} };
    gouraud_program = LoadShaders(gouraud_shaders);
    gouraud_vPos = glGetAttribLocation(gouraud_program, "vPosition");
    gouraud_vNorm = glGetAttribLocation(gouraud_program, "vNormal");
    gouraud_camera_mat_loc = glGetUniformLocation(gouraud_program, "camera_matrix");
    gouraud_model_mat_loc = glGetUniformLocation(gouraud_program, "model_matrix");
    gouraud_proj_mat_loc = glGetUniformLocation(gouraud_program, "proj_matrix");
    gouraud_norm_mat_loc = glGetUniformLocation(gouraud_program, "normal_matrix");
    gouraud_lights_block_idx = glGetUniformBlockIndex(gouraud_program, "LightBuffer");
    gouraud_materials_block_idx = glGetUniformBlockIndex(gouraud_program, "MaterialBuffer");
    gouraud_material_loc = glGetUniformLocation(gouraud_program, "Material");
    gouraud_eye_loc = glGetUniformLocation(gouraud_program, "EyePosition");

    // Load shaders and associate shader variables - texture shader
	ShaderInfo basic_tex_shaders[] = { {GL_VERTEX_SHADER, tex_vertex_shader},{GL_FRAGMENT_SHADER, tex_frag_shader},{GL_NONE, NULL} };
    basic_tex_program = LoadShaders(basic_tex_shaders);
    basic_tex_vPos = glGetAttribLocation(basic_tex_program, "vPosition");
    basic_tex_vTex = glGetAttribLocation(basic_tex_program, "vTexCoord");
    basic_tex_camera_mat_loc = glGetUniformLocation(basic_tex_program, "camera_matrix");
    basic_tex_model_mat_loc = glGetUniformLocation(basic_tex_program, "model_matrix");
    basic_tex_proj_mat_loc = glGetUniformLocation(basic_tex_program, "proj_matrix");

    // Enable depth test
    glEnable(GL_CULL_FACE);
    glEnable(GL_DEPTH_TEST);

    // Set Initial camera position
    GLfloat x, y, z;
    x = (GLfloat)(radius*sin(azimuth*DEG2RAD)*sin(elevation*DEG2RAD));
    y = (GLfloat)(radius*cos(elevation*DEG2RAD));
    z = (GLfloat)(radius*cos(azimuth*DEG2RAD)*sin(elevation*DEG2RAD));
    eye = vec3(x, y, z);

    // Start loop
    while ( !glfwWindowShouldClose( window ) ) {
    	// Draw graphics
        display();
        // Update other events like input handling
        glfwPollEvents();
        // Swap buffer onto screen
        glfwSwapBuffers( window );
    }

    // Close window
    glfwTerminate();
    return 0;

}

void display( )
{
    // Declare projection and camera matrices
    proj_matrix = mat4().identity();
    camera_matrix = mat4().identity();

	// Clear window and depth buffer
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    // Compute anisotropic scaling
    GLfloat xratio = 1.0f;
    GLfloat yratio = 1.0f;
    // If taller than wide adjust y
    if (ww <= hh)
    {
        yratio = (GLfloat)hh / (GLfloat)ww;
    }
        // If wider than tall adjust x
    else if (hh <= ww)
    {
        xratio = (GLfloat)ww / (GLfloat)hh;
    }

    // DEFAULT ORTHOGRAPHIC PROJECTION
    proj_matrix = ortho(-5.0f*xratio, 5.0f*xratio, -5.0f*yratio, 5.0f*yratio, -5.0f, 5.0f);

    // Set camera matrix
    camera_matrix = lookat(eye, center, up);

    // Render objects
	render_scene();

	// Flush pipeline
	glFlush();
}

void render_scene( ) {
    // Declare transformation matrices
    mat4 model_matrix = mat4().identity();
    mat4 scale_matrix = mat4().identity();
    mat4 rot_matrix = mat4().identity();
    mat4 trans_matrix = mat4().identity();

	// DRAW BASIC COLOR CUBE
    // Select shader program
    glUseProgram(col_mesh_program);
    // Pass projection matrix to shader
    glUniformMatrix4fv(col_mesh_proj_mat_loc, 1, GL_FALSE, proj_matrix);
    // Pass camera matrix to shader
    glUniformMatrix4fv(col_mesh_cam_mat_loc, 1, GL_FALSE, camera_matrix);

    // Set cube transformation matrix
    trans_matrix = translate(0.0f, 0.0f, 0.0f);
    rot_matrix = rotate(0.0f, vec3(0.0f, 0.0f, 1.0f));
    scale_matrix = scale(1.0f, 1.0f, 1.0f);
	model_matrix = trans_matrix*rot_matrix*scale_matrix;
    glUniformMatrix4fv(col_mesh_model_mat_loc, 1, GL_FALSE, model_matrix);
    // Draw cube
    draw_color_obj(Cube, RedCube);
}

void build_geometry( )
{
    // Model vectors
    vector<vec4> vertices;
    vector<vec2> uvCoords;
    vector<vec3> normals;

    // Generate vertex arrays and buffers
    glGenVertexArrays(NumVAOs, VAOs);

    // Load models
    load_color_object(Cube);

    // Generate color buffers
    glGenBuffers(NumColorBuffers, ColorBuffers);

    // Build color buffers
    // Define cube vertex colors (red)
    build_color_buffer(Cube, vec4(1.0f, 0.0f, 0.0f, 1.0f), ColorBuffers[RedCube]);

}

void load_color_object(GLuint obj) {
    vector<vec4> vertices;
    vector<vec2> uvCoords;
    vector<vec3> normals;

	// TODO: Load model and set number of vertices
    loadOBJ(objFiles[obj], vertices, uvCoords, normals);
    numVertices[obj] = vertices.size();

    // Create and load object position buffer
    glGenBuffers(NumObjBuffers, ObjBuffers[obj]);
    glBindVertexArray(VAOs[obj]);
    glBindBuffer(GL_ARRAY_BUFFER, ObjBuffers[obj][PosBuffer]);
    glBufferData(GL_ARRAY_BUFFER, sizeof(GLfloat)*posCoords*numVertices[obj], vertices.data(), GL_STATIC_DRAW);
    glBindBuffer(GL_ARRAY_BUFFER, 0);
}

void build_color_buffer(GLuint obj, vec4 color, GLuint buffer) {
    vector<vec4> temp;
    for (int i = 0; i < numVertices[obj]; i++) {
        temp.push_back(color);
    }

    glBindBuffer(GL_ARRAY_BUFFER, buffer);
    glBufferData(GL_ARRAY_BUFFER, sizeof(GLfloat)*colCoords*numVertices[obj], temp.data(), GL_STATIC_DRAW);
}

void draw_color_obj(GLuint obj, GLuint color) {
    glBindVertexArray(VAOs[obj]);
    glBindBuffer(GL_ARRAY_BUFFER, ObjBuffers[obj][PosBuffer]);
    glVertexAttribPointer(col_mesh_vPos, posCoords, GL_FLOAT, GL_FALSE, 0, NULL);
    glEnableVertexAttribArray(col_mesh_vPos);
    glBindBuffer(GL_ARRAY_BUFFER, ColorBuffers[color]);
    glVertexAttribPointer(col_mesh_vCol, colCoords, GL_FLOAT, GL_FALSE, 0, NULL);
    glEnableVertexAttribArray(col_mesh_vCol);
    glDrawArrays(GL_TRIANGLES, 0, numVertices[obj]);
}

void build_materials( ) {

}

void build_lights( ) {

}

void load_mat_object(GLuint obj) {
    vector<vec4> vertices;
    vector<vec2> uvCoords;
    vector<vec3> normals;

    // Load model and set number of vertices
    loadOBJ(objFiles[obj], vertices, uvCoords, normals);
    numVertices[obj] = vertices.size();

    // Create and load object position and normal buffers
    glGenBuffers(NumObjBuffers, ObjBuffers[obj]);
    glBindVertexArray(VAOs[obj]);
    glBindBuffer(GL_ARRAY_BUFFER, ObjBuffers[obj][PosBuffer]);
    glBufferData(GL_ARRAY_BUFFER, sizeof(GLfloat)*posCoords*numVertices[obj], vertices.data(), GL_STATIC_DRAW);
    glBindBuffer(GL_ARRAY_BUFFER, ObjBuffers[obj][NormBuffer]);
    glBufferData(GL_ARRAY_BUFFER, sizeof(GLfloat)*normCoords*numVertices[obj], normals.data(), GL_STATIC_DRAW);
    glBindBuffer(GL_ARRAY_BUFFER, 0);

}

void draw_mat_object(GLuint obj){
    glBindVertexArray(VAOs[obj]);
    glBindBuffer(GL_ARRAY_BUFFER, ObjBuffers[obj][PosBuffer]);
    glVertexAttribPointer(gouraud_vPos, posCoords, GL_FLOAT, GL_FALSE, 0, NULL);
    glEnableVertexAttribArray(gouraud_vPos);
    glBindBuffer(GL_ARRAY_BUFFER, ObjBuffers[obj][NormBuffer]);
    glVertexAttribPointer(gouraud_vNorm, normCoords, GL_FLOAT, GL_FALSE, 0, NULL);
    glEnableVertexAttribArray(gouraud_vNorm);
    glDrawArrays(GL_TRIANGLES, 0, numVertices[obj]);
}

void build_textures( ) {

}

void load_tex_object(GLuint obj) {
    vector<vec4> vertices;
    vector<vec2> uvCoords;
    vector<vec3> normals;

    // Load model and set number of vertices
    loadOBJ(objFiles[obj], vertices, uvCoords, normals);
    numVertices[obj] = vertices.size();

    // Create and load object position and texture coordinate buffers
    glGenBuffers(NumObjBuffers, ObjBuffers[obj]);
    glBindVertexArray(VAOs[obj]);
    glBindBuffer(GL_ARRAY_BUFFER, ObjBuffers[obj][PosBuffer]);
    glBufferData(GL_ARRAY_BUFFER, sizeof(GLfloat)*posCoords*numVertices[obj], vertices.data(), GL_STATIC_DRAW);
    glBindBuffer(GL_ARRAY_BUFFER, ObjBuffers[obj][TexBuffer]);
    glBufferData(GL_ARRAY_BUFFER, sizeof(GLfloat)*texCoords*numVertices[obj], uvCoords.data(), GL_STATIC_DRAW);
    glBindBuffer(GL_ARRAY_BUFFER, 0);
}

void draw_tex_object(GLuint obj){
    glBindVertexArray(VAOs[obj]);
    glBindBuffer(GL_ARRAY_BUFFER, ObjBuffers[obj][PosBuffer]);
    glVertexAttribPointer(basic_tex_vPos, posCoords, GL_FLOAT, GL_FALSE, 0, NULL);
    glEnableVertexAttribArray(basic_tex_vPos);
    glBindBuffer(GL_ARRAY_BUFFER, ObjBuffers[obj][TexBuffer]);
    glVertexAttribPointer(basic_tex_vTex, texCoords, GL_FLOAT, GL_FALSE, 0, NULL);
    glEnableVertexAttribArray(basic_tex_vTex);
    glDrawArrays(GL_TRIANGLES, 0, numVertices[obj]);

}

void key_callback(GLFWwindow *window, int key, int scancode, int action, int mods) {
    // ESC to quit
    if (key == GLFW_KEY_ESCAPE) {
        glfwSetWindowShouldClose(window, true);
    }

    // Adjust azimuth
    if (key == GLFW_KEY_A) {
        azimuth += daz;
        if (azimuth > 360.0) {
            azimuth -= 360.0;
        }
    } else if (key == GLFW_KEY_D) {
        azimuth -= daz;
        if (azimuth < 0.0)
        {
            azimuth += 360.0;
        }
    }

    // Adjust elevation angle
    if (key == GLFW_KEY_W)
    {
        elevation += del;
        if (elevation > 179.0)
        {
            elevation = 179.0;
        }
    }
    else if (key == GLFW_KEY_S)
    {
        elevation -= del;
        if (elevation < 1.0)
        {
            elevation = 1.0;
        }
    }

    // Compute updated camera position
    GLfloat x, y, z;
    x = (GLfloat)(radius*sin(azimuth*DEG2RAD)*sin(elevation*DEG2RAD));
    y = (GLfloat)(radius*cos(elevation*DEG2RAD));
    z = (GLfloat)(radius*cos(azimuth*DEG2RAD)*sin(elevation*DEG2RAD));
    eye = vec3(x,y,z);

}

void mouse_callback(GLFWwindow *window, int button, int action, int mods){

}

void framebuffer_size_callback(GLFWwindow *window, int width, int height) {
    glViewport(0, 0, width, height);

    ww = width;
    hh = height;
}

