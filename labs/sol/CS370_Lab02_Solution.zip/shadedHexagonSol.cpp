#include <stdio.h>
#include "../common/vgl.h"
#include "../common/utils.h"

// Vertex array and buffer names
enum VAO_IDs {Hexagon, NumVAOs};
enum Obj_Buffer_IDs {PosBuffer, IndexBuffer, NumObjBuffers};
enum Color_Buffer_IDs {Gradient, NumColorBuffers};

// Vertex array and buffer objects
GLuint VAOs[NumVAOs];
GLuint ObjBuffers[NumVAOs][NumObjBuffers];
GLuint ColorBuffers[NumColorBuffers];

// Number of indices in each object
GLint numIndices[NumVAOs];

// Number of component coordinates
GLint posCoords = 2;
GLint colCoords = 4;

// Shader variables
// Shader program reference
GLuint color_program;
// Shader component references
GLuint color_vPos;
GLuint color_vCol;
// Shader source files
const char *color_vertex_shader = "../basic.vert";
const char *color_frag_shader = "../basic.frag";

void display( );
void render_scene( );
void build_geometry( );

int main(int argc, char**argv)
{
	// Create OpenGL window
	GLFWwindow* window = CreateWindow("Shaded Hexagon");
    if (!window) {
        fprintf(stderr, "ERROR: could not open window with GLFW3\n");
        glfwTerminate();
        return 1;
    } else {
        printf("OpenGL window successfully created\n");
    }

	// Create geometry buffers
    build_geometry();
    
    // Load shaders and associate shader variables
	ShaderInfo color_shaders[] = { {GL_VERTEX_SHADER, color_vertex_shader},{GL_FRAGMENT_SHADER, color_frag_shader},{GL_NONE, NULL} };
	color_program = LoadShaders(color_shaders);
	color_vPos = glGetAttribLocation(color_program, "vPosition");
    color_vCol = glGetAttribLocation(color_program, "vColor");

    // Start loop
    while ( !glfwWindowShouldClose( window ) ) {
        // Draw graphics
        display();
        // Update other events like input handling
        glfwPollEvents();
        // Swap buffer onto screen
        glfwSwapBuffers( window );
    }

    // Close window
    glfwTerminate();
    return 0;
}

void display( )
{
	// Clear window
	glClear(GL_COLOR_BUFFER_BIT);

	// Render objects
	render_scene();

	// Flush pipeline
	glFlush();
}

void render_scene() {
	// Select shader program and bind vertex array and buffer
	glUseProgram(color_program);
    glBindVertexArray(VAOs[Hexagon]);
    glBindBuffer(GL_ARRAY_BUFFER, ObjBuffers[Hexagon][PosBuffer]);
    glVertexAttribPointer(color_vPos, posCoords, GL_FLOAT, GL_FALSE, 0, NULL);
    glEnableVertexAttribArray(color_vPos);
	// TODO: Bind color buffer
    glBindBuffer(GL_ARRAY_BUFFER, ColorBuffers[Gradient]);
    glVertexAttribPointer(color_vCol, colCoords, GL_FLOAT, GL_FALSE, 0, NULL);
    glEnableVertexAttribArray(color_vCol);

	// TODO: Draw indexed geometry
    glDrawElements(GL_TRIANGLES, numIndices[Hexagon], GL_UNSIGNED_SHORT, NULL);
}

void build_geometry( )
{
	// Generate and bind vertex arrays
	glGenVertexArrays(NumVAOs, VAOs);
	glBindVertexArray(VAOs[Hexagon]);

	// Define vertices (no particular orientation)
	GLfloat vertices[][2] = {
		{1.0f, 0.0f},
		{0.5f, 0.866f},
		{-0.5f, 0.866f},
		{-1.0f, 0.0f},
		{-0.5f, -0.866f},
		{0.5f, -0.866f}
	};

	// TODO: Define colors per vertex
    GLfloat colors[][4] = {
            {0.0f, 0.0f, 1.0f, 1.0f},
            {1.0f, 0.0f, 0.0f, 1.0f},
            {1.0f, 0.0f, 0.0f, 1.0f},
            {0.0f, 1.0f, 0.0f, 1.0f},
            {0.0f, 1.0f, 0.0f, 1.0f},
            {0.0f, 0.0f, 1.0f, 1.0f}
    };

	// TODO: Define face indices (ensure proper orientation)
    GLushort indices[] = {
            0, 1, 2,
            2, 3, 4,
            4, 5, 0,
            0, 2, 4
    };

    // TODO: Set numInidices
    numIndices[Hexagon] = 12;

	// Generate vertex buffers for hexagon
	glGenBuffers(NumObjBuffers, ObjBuffers[Hexagon]);
	glGenBuffers(NumColorBuffers, ColorBuffers);

	// Bind vertex positions
	glBindBuffer(GL_ARRAY_BUFFER, ObjBuffers[Hexagon][PosBuffer]);
	glBufferData(GL_ARRAY_BUFFER, sizeof(vertices), vertices, GL_STATIC_DRAW);

    // TODO: Bind vertex colors
    glBindBuffer(GL_ARRAY_BUFFER, ColorBuffers[Gradient]);
    glBufferData(GL_ARRAY_BUFFER, sizeof(colors), colors, GL_STATIC_DRAW);

    // TODO: Bind indices
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, ObjBuffers[Hexagon][IndexBuffer]);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indices), indices, GL_STATIC_DRAW);

}

