#ifndef CS370_LAB14_SCENE_H
#define CS370_LAB14_SCENE_H

// Define object dimensions
#define BASE_RADIUS 2.0f
#define BASE_HEIGHT 1.0f
#define LOWER_HEIGHT 2.0f
#define LOWER_WIDTH 1.0f
#define LOWER_DEPTH 0.5f
#define UPPER_HEIGHT 1.5f
#define UPPER_WIDTH 0.5f
#define UPPER_DEPTH 0.5f

#endif //CS370_LAB14_SCENE_H
