#define STB_IMAGE_IMPLEMENTATION
#include "../common/stb_image.h"	// Sean Barrett's image loader - http://nothings.org/
#include <stdio.h>
#include <vector>
#include "../common/vgl.h"
#include "../common/objloader.h"
#include "../common/utils.h"
#include "../common/vmath.h"
#include "lighting.h"
#include "MatNode.h"
#include "TexNode.h"
#include "scene.h"

using namespace vmath;
using namespace std;

enum VAO_IDs {Cube, Cylinder, Sphere, NumVAOs};
enum ObjBuffer_IDs {PosBuffer, NormBuffer, TexBuffer, NumObjBuffers};
enum LightBuffer_IDs {LightBuffer, NumLightBuffers};
enum LightNames {WhiteDirLight, GreenPointLight, RedSpotLight};
enum MaterialBuffer_IDs {MaterialBuffer, NumMaterialBuffers};
enum MaterialNames {Brass, RedPlastic};
enum Textures {Earth, NumTextures};

GLuint VAOs[NumVAOs];
GLuint ObjBuffers[NumVAOs][NumObjBuffers];
GLuint LightBuffers[NumLightBuffers];
GLuint MaterialBuffers[NumMaterialBuffers];
GLuint TextureIDs[NumTextures];

GLint numVertices[NumVAOs];
GLint posCoords = 4;
GLint normCoords = 3;
GLint texCoords = 2;

// Model files
vector<const char *> objFiles = {"../models/cube.obj", "../models/cylinder.obj", "../models/uv_sphere.obj"};

// Texture files
vector<const char *> texFiles = {"../textures/earth.bmp"};

// Camera
vec3 eye = {4.0f, 4.0f, 4.0f};
vec3 center = {0.0f, 0.0f, 0.0f};
vec3 up = {0.0f, 1.0f, 0.0f};

// Shader variables
// Light shader program reference
GLuint phong_program;
// Light shader component references
GLuint phong_vPos;
GLuint phong_vNorm;
GLuint phong_camera_mat_loc;
GLuint phong_model_mat_loc;
GLuint phong_proj_mat_loc;
GLuint phong_norm_mat_loc;
GLuint phong_lights_block_idx;
GLuint phong_materials_block_idx;
GLuint phong_material_loc;
GLuint phong_num_lights_loc;
GLuint phong_light_on_loc;
GLuint phong_eye_loc;
const char *phong_vertex_shader = "../phong.vert";
const char *phong_frag_shader = "../phong.frag";

// Texture shader program reference
GLuint tex_program;
// Texture shader component references
GLuint tex_vPos;
GLuint tex_vTex;
GLuint tex_camera_mat_loc;
GLuint tex_model_mat_loc;
GLuint tex_proj_mat_loc;
const char *tex_vertex_shader = "../basicTex.vert";
const char *tex_frag_shader = "../basicTex.frag";

// Global state
mat4 proj_matrix;
mat4 camera_matrix;

// Global light and material variables
vector<LightProperties> Lights;
vector<MaterialProperties> Materials;
GLuint numLights;
GLint lightOn[8] = {0, 0, 0, 0, 0, 0, 0, 0};

// Scene graph nodes
MatNode base;
MatNode lower_arm;
MatNode left_upper_arm;
MatNode right_upper_arm;
TexNode earth;

// Global object rotation angles
GLfloat theta = 0.0f;
GLfloat dtheta = 1.0f;
GLfloat phi = 0.0f;
GLfloat dphi = 1.0f;
GLfloat left_psi = 0.0f;
GLfloat right_psi = 0.0f;
GLfloat dpsi = 1.0f;
GLfloat earth_angle = 0.0f;
GLfloat rpm = 10.0f;
GLdouble elTime = 0.0;

// Global screen dimensions
GLint ww,hh;

void display( );
void render_scene( );
void build_geometry( );
void build_materials( );
void build_lights( );
void build_textures();
void build_scene_graph( );
void traverse_scene_graph(BaseNode *node, mat4 baseTransform);
void load_object(GLuint obj);
void framebuffer_size_callback(GLFWwindow *window, int width, int height);
void key_callback(GLFWwindow *window, int key, int scancode, int action, int mods);
void mouse_callback(GLFWwindow *window, int button, int action, int mods);

int main(int argc, char**argv)
{
	// Create OpenGL window
	GLFWwindow* window = CreateWindow("Robot Graph");
    if (!window) {
        fprintf(stderr, "ERROR: could not open window with GLFW3\n");
        glfwTerminate();
        return 1;
    } else {
        printf("OpenGL window successfully created\n");
    }

    // Store initial window size
    glfwGetFramebufferSize(window, &ww, &hh);

    // Register callbacks
    glfwSetFramebufferSizeCallback(window, framebuffer_size_callback);
    glfwSetKeyCallback(window,key_callback);
    glfwSetMouseButtonCallback(window, mouse_callback);

    // Load shaders
    // Load light shader
    ShaderInfo phong_shaders[] = { {GL_VERTEX_SHADER, phong_vertex_shader},{GL_FRAGMENT_SHADER, phong_frag_shader},{GL_NONE, NULL} };
    phong_program = LoadShaders(phong_shaders);
    phong_vPos = glGetAttribLocation(phong_program, "vPosition");
    phong_vNorm = glGetAttribLocation(phong_program, "vNormal");
    phong_camera_mat_loc = glGetUniformLocation(phong_program, "camera_matrix");
    phong_model_mat_loc = glGetUniformLocation(phong_program, "model_matrix");
    phong_proj_mat_loc = glGetUniformLocation(phong_program, "proj_matrix");
    phong_norm_mat_loc = glGetUniformLocation(phong_program, "normal_matrix");
    phong_lights_block_idx = glGetUniformBlockIndex(phong_program, "LightBuffer");
    phong_materials_block_idx = glGetUniformBlockIndex(phong_program, "MaterialBuffer");
    phong_material_loc = glGetUniformLocation(phong_program, "Material");
    phong_num_lights_loc = glGetUniformLocation(phong_program, "NumLights");
    phong_light_on_loc = glGetUniformLocation(phong_program, "LightOn");
    phong_eye_loc = glGetUniformLocation(phong_program, "EyePosition");

    // Load texture shaders
    ShaderInfo tex_shaders[] = { {GL_VERTEX_SHADER, tex_vertex_shader},{GL_FRAGMENT_SHADER, tex_frag_shader},{GL_NONE, NULL} };
    tex_program = LoadShaders(tex_shaders);
    tex_vPos = glGetAttribLocation(tex_program, "vPosition");
    tex_vTex = glGetAttribLocation(tex_program, "vTexCoord");
    tex_camera_mat_loc = glGetUniformLocation(tex_program, "camera_matrix");
    tex_model_mat_loc = glGetUniformLocation(tex_program, "model_matrix");
    tex_proj_mat_loc = glGetUniformLocation(tex_program, "proj_matrix");

    // Create geometry buffers
    build_geometry();
    // Create light buffers
    build_lights();
    // Create material buffers
    build_materials();
    // Create textures
    build_textures();
    // Create scene graph
    build_scene_graph();

    // Enable depth test
    glEnable(GL_CULL_FACE);
    glEnable(GL_DEPTH_TEST);

	// Start loop
    while ( !glfwWindowShouldClose( window ) ) {
    	// Draw graphics
        display();
        // Update other events like input handling
        glfwPollEvents();
        // Update angle based on time for fixed rpm
        GLdouble curTime = glfwGetTime();
        earth_angle += (curTime-elTime)*(rpm/60.0)*360.0;
        elTime = curTime;
        // TODO: Update earth node transformation
        earth.update_transform(translate(vec3(0.0f, 3.0f, 5.0f))*rotate(earth_angle, vec3(0.0f, 1.0f, 0.0f)));
        // Swap buffer onto screen
        glfwSwapBuffers( window );
    }

    // Close window
    glfwTerminate();
    return 0;
}

void display( )
{
    proj_matrix = mat4().identity();
    camera_matrix = mat4().identity();

	// Clear window
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    // Set projection matrix
    // Set orthographic viewing volume anisotropic
    GLfloat xratio = 1.0f;
    GLfloat yratio = 1.0f;
    // If taller than wide adjust y
    if (ww <= hh)
    {
        yratio = (GLfloat)hh / (GLfloat)ww;
    }
        // If wider than tall adjust x
    else if (hh <= ww)
    {
        xratio = (GLfloat)ww / (GLfloat)hh;
    }
    proj_matrix = ortho(-10.0f*xratio, 10.0f*xratio, -10.0f*yratio, 10.0f*yratio, -10.0f, 10.0f);

    // Set camera matrix
    camera_matrix = lookat(eye, center, up);

    // Render objects
	render_scene();

	glFlush();
}

void render_scene( ) {
    // TODO: Traverse scene graph with base as root
    traverse_scene_graph(&base, mat4().identity());
}

void build_geometry( )
{
    // Generate vertex arrays for objects
    glGenVertexArrays(NumVAOs, VAOs);

    // Load objects (with both normals and texture coords)
    load_object(Cube);
    load_object(Cylinder);
    load_object(Sphere);
}

void build_materials( ) {
    // Create brass material
    MaterialProperties brass = {vec4(0.33f, 0.22f, 0.03f, 1.0f), //ambient
                                vec4(0.78f, 0.57f, 0.11f, 1.0f), //diffuse
                                vec4(0.99f, 0.91f, 0.81f, 1.0f), //specular
                                27.8f, //shininess
                                {0.0f, 0.0f, 0.0f}  //pad
    };

    // Create red plastic material
    MaterialProperties redPlastic = {vec4(0.3f, 0.0f, 0.0f, 1.0f), //ambient
                                     vec4(0.6f, 0.0f, 0.0f, 1.0f), //diffuse
                                     vec4(0.8f, 0.6f, 0.6f, 1.0f), //specular
                                     32.0f, //shininess
                                     {0.0f, 0.0f, 0.0f}  //pad
    };

    // Add materials to Materials vector
    Materials.push_back(brass);
    Materials.push_back(redPlastic);

    // Create uniform buffer for materials
    glGenBuffers(NumMaterialBuffers, MaterialBuffers);
    glBindBuffer(GL_UNIFORM_BUFFER, MaterialBuffers[MaterialBuffer]);
    glBufferData(GL_UNIFORM_BUFFER, Materials.size()*sizeof(MaterialProperties), Materials.data(), GL_STATIC_DRAW);
}

void build_lights( ) {
    // White directional light
    LightProperties whiteDirLight = {DIRECTIONAL, //type
                                     {0.0f, 0.0f, 0.0f}, //pad
                                     vec4(0.0f, 0.0f, 0.0f, 1.0f), //ambient
                                     vec4(1.0f, 1.0f, 1.0f, 1.0f), //diffuse
                                     vec4(1.0f, 1.0f, 1.0f, 1.0f), //specular
                                     vec4(0.0f, 0.0f, 0.0f, 1.0f),  //position
                                     vec4(-1.0f, -1.0f, -1.0f, 0.0f), //direction
                                     0.0f,   //cutoff
                                     0.0f,  //exponent
                                     {0.0f, 0.0f}  //pad2
    };

    // Green point light
    LightProperties greenPointLight = {POINT, //type
                                       {0.0f, 0.0f, 0.0f}, //pad
                                       vec4(0.0f, 0.0f, 0.0f, 1.0f), //ambient
                                       vec4(0.0f, 1.0f, 0.0f, 1.0f), //diffuse
                                       vec4(0.0f, 1.0f, 0.0f, 1.0f), //specular
                                       vec4(3.0f, 3.0f, 3.0f, 1.0f),  //position
                                       vec4(0.0f, 0.0f, 0.0f, 0.0f), //direction
                                       0.0f,   //cutoff
                                       0.0f,  //exponent
                                       {0.0f, 0.0f}  //pad2
    };

    //Red spot light
    LightProperties redSpotLight = {SPOT, //type
                                    {0.0f, 0.0f, 0.0f}, //pad
                                    vec4(0.0f, 0.0f, 0.0f, 1.0f), //ambient
                                    vec4(0.0f, 1.0f, 0.0f, 1.0f), //diffuse
                                    vec4(1.0f, 1.0f, 1.0f, 1.0f), //specular
                                    vec4(0.0f, 6.0f, 0.0f, 1.0f),  //position
                                    vec4(0.0f, -1.0f, 0.0f, 0.0f), //direction
                                    30.0f,   //cutoff
                                    30.0f,  //exponent
                                    {0.0f, 0.0f}  //pad2
    };


    // Add lights to Lights vector
    Lights.push_back(whiteDirLight);
    Lights.push_back(greenPointLight);
    Lights.push_back(redSpotLight);
    numLights = Lights.size();
    // Turn all lights on
    for (int i = 0; i < numLights; i++) {
        lightOn[i] = 1;
    }

    // Create uniform buffer for lights
    glGenBuffers(NumLightBuffers, LightBuffers);
    glBindBuffer(GL_UNIFORM_BUFFER, LightBuffers[LightBuffer]);
    glBufferData(GL_UNIFORM_BUFFER, Lights.size()*sizeof(LightProperties), Lights.data(), GL_STATIC_DRAW);
}

void build_textures( ) {
    int w, h, n;
    int force_channels = 4;
    unsigned char *image_data;

    // Create textures and activate unit 0
    glGenTextures( NumTextures,  TextureIDs);
    glActiveTexture( GL_TEXTURE0 );

    for (int i = 0; i < NumTextures; i++) {
        // Load image from file
        image_data = stbi_load(texFiles[i], &w, &h, &n, force_channels);
        if (!image_data) {
            fprintf(stderr, "ERROR: could not load %s\n", texFiles[i]);
        }
        // NPOT check for power of 2 dimensions
        if ((w & (w - 1)) != 0 || (h & (h - 1)) != 0) {
            fprintf(stderr, "WARNING: texture %s is not power-of-2 dimensions\n",
                    texFiles[i]);
        }

        // Bind current texture id
        glBindTexture(GL_TEXTURE_2D, TextureIDs[i]);
        // Load image data into texture
        glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, w, h, 0, GL_RGBA, GL_UNSIGNED_BYTE,
                     image_data);
        // Generate mipmaps for texture
        glGenerateMipmap( GL_TEXTURE_2D );
        // Set scaling modes
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
        // Set wrapping modes
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
        // Set maximum anisotropic filtering for system
        GLfloat max_aniso = 0.0f;
        glGetFloatv(GL_MAX_TEXTURE_MAX_ANISOTROPY_EXT, &max_aniso);
        // set the maximum!
        glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAX_ANISOTROPY_EXT, max_aniso);
    }
}

void build_scene_graph( ) {
	// TODO: Add base node
    base.set_shader(phong_program, phong_proj_mat_loc, phong_camera_mat_loc, phong_model_mat_loc);
    base.NormMatPtr = phong_norm_mat_loc;
    base.set_buffers(VAOs[Cylinder], ObjBuffers[Cylinder][PosBuffer], phong_vPos, posCoords, ObjBuffers[Cylinder][NormBuffer], phong_vNorm, normCoords, numVertices[Cylinder]);
	base.set_materials(MaterialBuffers[MaterialBuffer], phong_materials_block_idx, Materials.size()*sizeof(MaterialProperties), phong_material_loc, RedPlastic);
    base.set_lights(LightBuffers[LightBuffer], phong_lights_block_idx, Lights.size()*sizeof(LightProperties), phong_num_lights_loc, Lights.size(), phong_light_on_loc, lightOn);
    base.set_eye(phong_eye_loc, eye);
    base.set_base_transform(scale(vec3(BASE_RADIUS, BASE_HEIGHT, BASE_RADIUS)));
	base.update_transform(rotate(theta, vec3(0.0f, 1.0f, 0.0f)));
    base.sibling = &earth;
    base.child = &lower_arm;

	// TODO: Add lower arm node (child of base)
    lower_arm.set_shader(phong_program, phong_proj_mat_loc, phong_camera_mat_loc, phong_model_mat_loc);
    lower_arm.NormMatPtr = phong_norm_mat_loc;
    lower_arm.set_buffers(VAOs[Cube], ObjBuffers[Cube][PosBuffer], phong_vPos, posCoords, ObjBuffers[Cube][NormBuffer], phong_vNorm, normCoords, numVertices[Cube]);
    lower_arm.set_materials(MaterialBuffers[MaterialBuffer], phong_materials_block_idx, Materials.size()*sizeof(MaterialProperties), phong_material_loc, Brass);
    lower_arm.set_lights(LightBuffers[LightBuffer], phong_lights_block_idx, Lights.size()*sizeof(LightProperties), phong_num_lights_loc, Lights.size(), phong_light_on_loc, lightOn);
    lower_arm.set_eye(phong_eye_loc, eye);
    lower_arm.set_base_transform(translate(vec3(0.0f, LOWER_HEIGHT, 0.0f))*scale(vec3(LOWER_WIDTH, LOWER_HEIGHT, LOWER_DEPTH)));
    lower_arm.update_transform(translate(vec3(0.0f, BASE_HEIGHT, 0.0f))*rotate(phi, vec3(1.0f, 0.0f, 0.0f)));
    lower_arm.sibling = NULL;
    lower_arm.child = &left_upper_arm;

	// TODO: Add left upper arm node (child of lower arm)
    left_upper_arm.set_shader(phong_program, phong_proj_mat_loc, phong_camera_mat_loc, phong_model_mat_loc);
    left_upper_arm.NormMatPtr = phong_norm_mat_loc;
    left_upper_arm.set_buffers(VAOs[Cube], ObjBuffers[Cube][PosBuffer], phong_vPos, posCoords, ObjBuffers[Cube][NormBuffer], phong_vNorm, normCoords, numVertices[Cube]);
    left_upper_arm.set_materials(MaterialBuffers[MaterialBuffer], phong_materials_block_idx, Materials.size()*sizeof(MaterialProperties), phong_material_loc, RedPlastic);
    left_upper_arm.set_lights(LightBuffers[LightBuffer], phong_lights_block_idx, Lights.size()*sizeof(LightProperties), phong_num_lights_loc, Lights.size(), phong_light_on_loc, lightOn);
    left_upper_arm.set_eye(phong_eye_loc, eye);
    left_upper_arm.set_base_transform(translate(vec3(0.0f, UPPER_HEIGHT, 0.0f))*scale(vec3(UPPER_WIDTH, UPPER_HEIGHT, UPPER_DEPTH)));
    left_upper_arm.update_transform(translate(vec3((LOWER_WIDTH+UPPER_WIDTH), 2*LOWER_HEIGHT, 0.0f))*rotate(left_psi, vec3(1.0f, 0.0f, 0.0f)));
    left_upper_arm.sibling = &right_upper_arm;
    left_upper_arm.child = NULL;

	// TODO: Add right upper arm node (sibling of left upper arm)
    right_upper_arm.set_shader(phong_program, phong_proj_mat_loc, phong_camera_mat_loc, phong_model_mat_loc);
    right_upper_arm.NormMatPtr = phong_norm_mat_loc;
    right_upper_arm.set_buffers(VAOs[Cube], ObjBuffers[Cube][PosBuffer], phong_vPos, posCoords, ObjBuffers[Cube][NormBuffer], phong_vNorm, normCoords, numVertices[Cube]);
    right_upper_arm.set_materials(MaterialBuffers[MaterialBuffer], phong_materials_block_idx, Materials.size()*sizeof(MaterialProperties), phong_material_loc, RedPlastic);
    right_upper_arm.set_lights(LightBuffers[LightBuffer], phong_lights_block_idx, Lights.size()*sizeof(LightProperties), phong_num_lights_loc, Lights.size(), phong_light_on_loc, lightOn);
    right_upper_arm.set_eye(phong_eye_loc, eye);
    right_upper_arm.set_base_transform(translate(vec3(0.0f, UPPER_HEIGHT, 0.0f))*scale(vec3(UPPER_WIDTH, UPPER_HEIGHT, UPPER_DEPTH)));
    right_upper_arm.update_transform(translate(vec3((-LOWER_WIDTH-UPPER_WIDTH), 2*LOWER_HEIGHT, 0.0f))*rotate(right_psi, vec3(1.0f, 0.0f, 0.0f)));
    right_upper_arm.sibling = NULL;
    right_upper_arm.child = NULL;

	// TODO: Add earth node (sibling of base)
    earth.set_shader(tex_program, tex_proj_mat_loc, tex_camera_mat_loc, tex_model_mat_loc);
    earth.set_buffers(VAOs[Sphere], ObjBuffers[Sphere][PosBuffer], tex_vPos, posCoords, ObjBuffers[Sphere][TexBuffer], tex_vTex, texCoords, numVertices[Sphere]);
    earth.TexID = TextureIDs[Earth];
    earth.set_base_transform(scale(1.5f, 1.5f, 1.5f));
    earth.update_transform(translate(vec3(0.0f, 3.0f, 5.0f))*rotate(earth_angle,vec3(0.0f, 1.0f, 0.0f)));
    earth.sibling = NULL;
    earth.child = NULL;

}

void traverse_scene_graph(BaseNode *node, mat4 baseTransform) {
    // Depth first traversal of child/sibling tree
    mat4 model_matrix;

    // Stop when at bottom of branch
    if (node == NULL) {
        return;
    }

    // Apply local transformation and render
    model_matrix = baseTransform*node->ModelTransform;

    node->draw(proj_matrix, camera_matrix, model_matrix);

    // Recurse vertically if possible (depth-first)
    if (node->child != NULL) {
        traverse_scene_graph(node->child, model_matrix);
    }

    // Remove local transformation and recurse horizontal
    if (node->sibling != NULL) {
        traverse_scene_graph(node->sibling, baseTransform);
    }
}

void load_object(GLuint obj) {
    vector<vec4> vertices;
    vector<vec2> uvCoords;
    vector<vec3> normals;

    loadOBJ(objFiles[obj], vertices, uvCoords, normals);
    numVertices[obj] = vertices.size();
    // Create and load object buffers
    glGenBuffers(NumObjBuffers, ObjBuffers[obj]);
    glBindVertexArray(VAOs[obj]);
    glBindBuffer(GL_ARRAY_BUFFER, ObjBuffers[obj][PosBuffer]);
    glBufferData(GL_ARRAY_BUFFER, sizeof(GLfloat)*posCoords*numVertices[obj], vertices.data(), GL_STATIC_DRAW);
    glBindBuffer(GL_ARRAY_BUFFER, ObjBuffers[obj][NormBuffer]);
    glBufferData(GL_ARRAY_BUFFER, sizeof(GLfloat)*normCoords*numVertices[obj], normals.data(), GL_STATIC_DRAW);
    glBindBuffer(GL_ARRAY_BUFFER, ObjBuffers[obj][TexBuffer]);
    glBufferData(GL_ARRAY_BUFFER, sizeof(GLfloat)*texCoords*numVertices[obj], uvCoords.data(), GL_STATIC_DRAW);
    glBindBuffer(GL_ARRAY_BUFFER, 0);

}

void key_callback(GLFWwindow *window, int key, int scancode, int action, int mods) {
    // ESC closes window
    if (key == GLFW_KEY_ESCAPE) {
        glfwSetWindowShouldClose(window, true);
    }

    // a d rotate base
    if (key == GLFW_KEY_D)
    {
        theta += dtheta;
        if (theta > 360.0f)
        {
            theta -= 360.0f;
        }
        // TODO: Update base
        base.update_transform(rotate(theta, vec3(0.0f, 1.0f, 0.0f)));
    }
    else if (key == GLFW_KEY_A)
    {
        theta -= dtheta;
        if (theta < 0.0f)
        {
            theta += 360.0f;
        }
        // TODO: Update base
        base.update_transform(rotate(theta, vec3(0.0f, 1.0f, 0.0f)));
    }

    // w s rotates lower arm
    if (key == GLFW_KEY_S)
    {
        phi += dphi;
        if (phi > 90.0f)
        {
            phi = 90.0f;
        }
        // TODO: Update lower arm
        lower_arm.update_transform(translate(vec3(0.0f, BASE_HEIGHT, 0.0f))*rotate(phi, vec3(1.0f, 0.0f, 0.0f)));
    }
    else if (key == GLFW_KEY_W)
    {
        phi -= dphi;
        if (phi < -90.0f)
        {
            phi = -90.0f;
        }
        // TODO: Update lower arm
        lower_arm.update_transform(translate(vec3(0.0f, BASE_HEIGHT, 0.0f))*rotate(phi, vec3(1.0f, 0.0f, 0.0f)));
    }

    // m n rotates left upper arm
    if (key == GLFW_KEY_N)
    {
        left_psi += dpsi;
        if (left_psi > 180.0f)
        {
            left_psi = 180.0f;
        }
        // TODO: Update left upper arm
        left_upper_arm.update_transform(translate(vec3((LOWER_WIDTH+UPPER_WIDTH), 2*LOWER_HEIGHT, 0.0f))*rotate(left_psi, vec3(1.0f, 0.0f, 0.0f)));
    }
    else if (key == GLFW_KEY_M)
    {
        left_psi -= dpsi;
        if (left_psi < -180.0f)
        {
            left_psi = -180.0f;
        }
        // TODO: Update left upper arm
        left_upper_arm.update_transform(translate(vec3((LOWER_WIDTH+UPPER_WIDTH), 2*LOWER_HEIGHT, 0.0f))*rotate(left_psi, vec3(1.0f, 0.0f, 0.0f)));
    }

    // . , rotates right upper arm
    if (key == GLFW_KEY_COMMA)
    {
        right_psi += dpsi;
        if (right_psi > 180.0f)
        {
            right_psi = 180.0f;
        }
        // TODO: Update right upper arm
        right_upper_arm.update_transform(translate(vec3(-(LOWER_WIDTH+UPPER_WIDTH), 2*LOWER_HEIGHT, 0.0f))*rotate(right_psi, vec3(1.0f, 0.0f, 0.0f)));
    }
    else if (key == GLFW_KEY_PERIOD)
    {
        right_psi -= dpsi;
        if (right_psi < -180.0f)
        {
            right_psi = -180.0f;
        }
        // TODO: Update right upper arm
        right_upper_arm.update_transform(translate(vec3(-(LOWER_WIDTH+UPPER_WIDTH), 2*LOWER_HEIGHT, 0.0f))*rotate(right_psi, vec3(1.0f, 0.0f, 0.0f)));
    }

    // Space toggles spotlight
    if (key == GLFW_KEY_SPACE && action == GLFW_PRESS) {
        lightOn[RedSpotLight] = (lightOn[RedSpotLight]+1)%2;
    }
}

void mouse_callback(GLFWwindow *window, int button, int action, int mods){

}

void framebuffer_size_callback(GLFWwindow *window, int width, int height) {
    glViewport(0, 0, width, height);

    ww = width;
    hh = height;
}


