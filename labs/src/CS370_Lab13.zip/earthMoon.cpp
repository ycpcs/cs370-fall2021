#define STB_IMAGE_IMPLEMENTATION
#include "../common/stb_image.h"	// Sean Barrett's image loader - http://nothings.org/
#include <stdio.h>
#include <vector>
#include "../common/vgl.h"
#include "../common/objloader.h"
#include "../common/utils.h"
#include "../common/vmath.h"

using namespace vmath;
using namespace std;

enum VAO_IDs {TexSphere, Background, NumVAOs};
enum ObjBuffer_IDs {PosBuffer, TexBuffer, NumObjBuffers};
enum Textures {Earth, Moon, Space, NumTextures};

GLuint VAOs[NumVAOs];
GLuint ObjBuffers[NumVAOs][NumObjBuffers];
GLuint TextureIDs[NumTextures];

GLint numVertices[NumVAOs];
GLint posCoords = 4;
GLint texCoords = 2;

// Model files
vector<const char *> objFiles = {"../models/uv_sphere.obj"};

// Texture files
vector<const char *> texFiles = {"../textures/earth.bmp", "../textures/moon.bmp", "../textures/space.jpg"};

// Camera
vec3 eye = {0.0f, 0.0f, 4.0f};
vec3 center = {0.0f, 0.0f, 0.0f};
vec3 up = {0.0f, 1.0f, 0.0f};

// Shader variables
// Shader program reference
GLuint basic_tex_program;
GLuint basic_tex_vPos;
GLuint basic_tex_vTex;
GLuint basic_tex_camera_mat_loc;
GLuint basic_tex_model_mat_loc;
GLuint basic_tex_proj_mat_loc;
GLuint basic_tex_eye_loc;
const char *vertex_shader = "../basicTex.vert";
const char *frag_shader = "../basicTex.frag";

// Global state
mat4 proj_matrix;
mat4 model_matrix;
mat4 camera_matrix;

// Global sphere variables
GLfloat earth_angle = 0.0f;
GLfloat moon_angle = 0.0f;
GLdouble elTime = 0.0;
GLdouble rpm = 10.0;
vec3 axis = {0.0f, 1.0f, 0.0f};

// Global screen dimensions
GLint ww,hh;

void display( );
void render_scene( );
void build_geometry( );
void build_textures();
void draw_background();
void load_tex_object(GLuint obj);
void draw_tex_object(GLuint obj);
void framebuffer_size_callback(GLFWwindow *window, int width, int height);
void key_callback(GLFWwindow *window, int key, int scancode, int action, int mods);
void mouse_callback(GLFWwindow *window, int button, int action, int mods);

int main(int argc, char**argv)
{
	// Create OpenGL window
	GLFWwindow* window = CreateWindow("Earth Moon");
    if (!window) {
        fprintf(stderr, "ERROR: could not open window with GLFW3\n");
        glfwTerminate();
        return 1;
    } else {
        printf("OpenGL window successfully created\n");
    }

    // Store initial window size
    glfwGetFramebufferSize(window, &ww, &hh);

    // Register callbacks
    glfwSetFramebufferSizeCallback(window, framebuffer_size_callback);
    glfwSetKeyCallback(window,key_callback);
    glfwSetMouseButtonCallback(window, mouse_callback);

	// Create geometry buffers
    build_geometry();
    // Create textures
    build_textures();
    
    // Load shaders
	ShaderInfo basic_tex_shaders[] = { {GL_VERTEX_SHADER, vertex_shader},{GL_FRAGMENT_SHADER, frag_shader},{GL_NONE, NULL} };
    basic_tex_program = LoadShaders(basic_tex_shaders);

	// Select shader program and associate shader variables
    basic_tex_vPos = glGetAttribLocation(basic_tex_program, "vPosition");
    basic_tex_vTex = glGetAttribLocation(basic_tex_program, "vTexCoord");
    basic_tex_camera_mat_loc = glGetUniformLocation(basic_tex_program, "camera_matrix");
    basic_tex_model_mat_loc = glGetUniformLocation(basic_tex_program, "model_matrix");
    basic_tex_proj_mat_loc = glGetUniformLocation(basic_tex_program, "proj_matrix");

    // Enable depth test
    glEnable(GL_CULL_FACE);
    glEnable(GL_DEPTH_TEST);

	// Start loop
    while ( !glfwWindowShouldClose( window ) ) {
    	// Draw graphics
        display();
        // Update other events like input handling
        glfwPollEvents();
        // Update angle based on time for fixed rpm
        GLdouble curTime = glfwGetTime();
        earth_angle += (curTime-elTime)*(rpm/60.0)*360.0;
        moon_angle += (curTime-elTime)*(rpm/60.0)*360.0;
        elTime = curTime;
        // Swap buffer onto screen
        glfwSwapBuffers( window );
    }

    // Close window
    glfwTerminate();
    return 0;
}

void display( )
{
    proj_matrix = mat4().identity();
    camera_matrix = mat4().identity();

	// Clear window
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    // Render background
	draw_background();

    // Set projection matrix
    // Set orthographic viewing volume anisotropic
    GLfloat xratio = 1.0f;
    GLfloat yratio = 1.0f;
    // If taller than wide adjust y
    if (ww <= hh)
    {
        yratio = (GLfloat)hh / (GLfloat)ww;
    }
        // If wider than tall adjust x
    else if (hh <= ww)
    {
        xratio = (GLfloat)ww / (GLfloat)hh;
    }
    // Set projection matrix
    proj_matrix = frustum(-1.0f*xratio, 1.0f*xratio, -1.0f*yratio, 1.0f*yratio, 1.0f, 100.0f);

    // Set camera matrix
    camera_matrix = lookat(eye, center, up);

    // Render objects
	render_scene();

	glFlush();
}

void render_scene( ) {
    mat4 scale_matrix = mat4().identity();
    mat4 rot_matrix = mat4().identity();
    mat4 trans_matrix = mat4().identity();
	mat4 rot2_matrix = mat4().identity();

    // Select shader program
    glUseProgram(basic_tex_program);
    // Pass projection and camera matrices to shader
    glUniformMatrix4fv(basic_tex_proj_mat_loc, 1, GL_FALSE, proj_matrix);
    glUniformMatrix4fv(basic_tex_camera_mat_loc, 1, GL_FALSE, camera_matrix);

    // Set earth transformation matrix
    trans_matrix = translation(0.0f, 0.0f, 0.0f);
    rot_matrix = rotation(earth_angle, normalize(axis));
    scale_matrix = scale(1.0f, 1.0f, 1.0f);
    model_matrix = trans_matrix*rot_matrix*scale_matrix;
    // Pass model matrix to shader
    glUniformMatrix4fv(basic_tex_model_mat_loc, 1, GL_FALSE, model_matrix);
    // TODO: Bind earth texture id

    // Draw earth
    draw_tex_object(TexSphere);

    // Set moon transformation matrix
    rot_matrix = rotation(moon_angle, normalize(axis));
    scale_matrix = scale(0.25f, 0.25f, 0.25f);
    trans_matrix = translation(2.0f, 0.0f, 0.0f);
    model_matrix = rot_matrix*trans_matrix*rot_matrix*scale_matrix;
    // Pass model matrix to shader
    glUniformMatrix4fv(basic_tex_model_mat_loc, 1, GL_FALSE, model_matrix);
    // TODO: Bind moon texture id

    // Draw moon
    draw_tex_object(TexSphere);
}

void build_geometry( )
{
    // Generate vertex arrays for objects
    glGenVertexArrays(NumVAOs, VAOs);

    // Load objects
    load_tex_object(TexSphere);

    // Create background quad
    vector<vec4> vertices;
    vector<vec2> uvCoords;

    vertices.push_back(vec4(1.0f, 1.0f, 0.0f, 1.0f));
    vertices.push_back(vec4(-1.0f, 1.0f, 0.0f, 1.0f));
    vertices.push_back(vec4(-1.0f, -1.0f, 0.0f, 1.0f));
    vertices.push_back(vec4(-1.0f, -1.0f, 0.0f, 1.0f));
    vertices.push_back(vec4(1.0f, -1.0f, 0.0f, 1.0f));
    vertices.push_back(vec4(1.0f, 1.0f, 0.0f, 1.0f));

    // TODO: Define texture coordinates

    numVertices[Background] = vertices.size();

    glBindVertexArray(VAOs[Background]);
    glGenBuffers(NumObjBuffers, ObjBuffers[Background]);
    // Bind position coordinate buffer and load data
    glBindBuffer(GL_ARRAY_BUFFER, ObjBuffers[Background][PosBuffer]);
    glBufferData(GL_ARRAY_BUFFER, sizeof(GLfloat)*posCoords*numVertices[Background], vertices.data(), GL_STATIC_DRAW);
    // Bind texture coordinate buffer and load data
    glBindBuffer(GL_ARRAY_BUFFER, ObjBuffers[Background][TexBuffer]);
    glBufferData(GL_ARRAY_BUFFER, sizeof(GLfloat)*texCoords*numVertices[Background], uvCoords.data(), GL_STATIC_DRAW);
}

void build_textures( ) {
    int w, h, n;
    int force_channels = 4;
    unsigned char *image_data;

    // Create textures and activate unit 0
    glGenTextures( NumTextures,  TextureIDs);
    glActiveTexture( GL_TEXTURE0 );

    for (int i = 0; i < NumTextures; i++) {
        // Load image from file
        image_data = stbi_load(texFiles[i], &w, &h, &n, force_channels);
        if (!image_data) {
            fprintf(stderr, "ERROR: could not load %s\n", texFiles[i]);
        }
        // NPOT check for power of 2 dimensions
        if ((w & (w - 1)) != 0 || (h & (h - 1)) != 0) {
            fprintf(stderr, "WARNING: texture %s is not power-of-2 dimensions\n",
                    texFiles[i]);
        }

        // TODO: Bind current texture id

        // TODO: Load image data into texture

        // TODO: Generate mipmaps for texture

        // TODO: Set scaling modes

        // TODO: Set wrapping modes

        // Set maximum anisotropic filtering for system
        GLfloat max_aniso = 0.0f;
        glGetFloatv(GL_MAX_TEXTURE_MAX_ANISOTROPY_EXT, &max_aniso);
        // set the maximum!
        glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAX_ANISOTROPY_EXT, max_aniso);
    }
}

void load_tex_object(GLuint obj) {
    vector<vec4> vertices;
    vector<vec2> uvCoords;
    vector<vec3> normals;

    // Load model and set number of vertices
    loadOBJ(objFiles[obj], vertices, uvCoords, normals);
    numVertices[obj] = vertices.size();

    // Create and load object position and texture coordinate buffers
    glGenBuffers(NumObjBuffers, ObjBuffers[obj]);
    glBindVertexArray(VAOs[obj]);
    glBindBuffer(GL_ARRAY_BUFFER, ObjBuffers[obj][PosBuffer]);
    glBufferData(GL_ARRAY_BUFFER, sizeof(GLfloat)*posCoords*numVertices[obj], vertices.data(), GL_STATIC_DRAW);
    glBindBuffer(GL_ARRAY_BUFFER, ObjBuffers[obj][TexBuffer]);
    glBufferData(GL_ARRAY_BUFFER, sizeof(GLfloat)*texCoords*numVertices[obj], uvCoords.data(), GL_STATIC_DRAW);
    glBindBuffer(GL_ARRAY_BUFFER, 0);
}

void draw_tex_object(GLuint obj){
    glBindVertexArray(VAOs[obj]);
    glBindBuffer(GL_ARRAY_BUFFER, ObjBuffers[obj][PosBuffer]);
    glVertexAttribPointer(basic_tex_vPos, posCoords, GL_FLOAT, GL_FALSE, 0, NULL);
    glEnableVertexAttribArray(basic_tex_vPos);
    glBindBuffer(GL_ARRAY_BUFFER, ObjBuffers[obj][TexBuffer]);
    glVertexAttribPointer(basic_tex_vTex, texCoords, GL_FLOAT, GL_FALSE, 0, NULL);
    glEnableVertexAttribArray(basic_tex_vTex);
    glDrawArrays(GL_TRIANGLES, 0, numVertices[obj]);

}

void draw_background(){
    // Set anisotropic scaling
    GLfloat xratio = 1.0f;
    GLfloat yratio = 1.0f;
    // If taller than wide adjust y
    if (ww <= hh)
    {
        yratio = (GLfloat)hh / (GLfloat)ww;
    }
        // If wider than tall adjust x
    else if (hh <= ww)
    {
        xratio = (GLfloat)ww / (GLfloat)hh;
    }
    // TODO: Set default orthographic projection

    // TODO: Set default camera matrix

    // Select shader program
    glUseProgram(basic_tex_program);
    // Pass projection matrix and camera matrices to shader
    glUniformMatrix4fv(basic_tex_proj_mat_loc, 1, GL_FALSE, proj_matrix);
    glUniformMatrix4fv(basic_tex_camera_mat_loc, 1, GL_FALSE, camera_matrix);

    // TODO: Set default model matrix for background

    // Pass model matrix to shader
    glUniformMatrix4fv(basic_tex_model_mat_loc, 1, GL_FALSE, model_matrix);
    // TODO: Bind Space texture id

    // TODO: Draw background with depth buffer writes disabled

}

void key_callback(GLFWwindow *window, int key, int scancode, int action, int mods) {
    // Move hexagon with arrow keys
    if (key == GLFW_KEY_ESCAPE) {
        glfwSetWindowShouldClose(window, true);
    }
}

void mouse_callback(GLFWwindow *window, int button, int action, int mods){

}

void framebuffer_size_callback(GLFWwindow *window, int width, int height) {
    glViewport(0, 0, width, height);

    ww = width;
    hh = height;
}