#include <stdio.h>
#include "../common/vgl.h"
#include "../common/utils.h"

// Vertex array and buffer names
enum VAO_IDs {Square, NumVAOs};
enum Obj_Buffer_IDs {PosBuffer, NumObjBuffers};

// Vertex array and buffer objects
GLuint VAOs[NumVAOs];
GLuint ObjBuffers[NumVAOs][NumObjBuffers];

// Number of vertices in each object
GLint numVertices[NumVAOs];

// Number of position coordinates
GLint posCoords = 2;

// Shader variables
// Shader program reference
GLuint simple_program;
// Shader position reference
GLuint simple_vPos;
// Shader source files
const char *simple_vertex_shader = "../basic.vert";
const char *simple_frag_shader = "../basic.frag";

void display( );
void render_scene( );
void build_geometry( );

int main(int argc, char**argv)
{
	// Create OpenGL window
	GLFWwindow* window = CreateWindow("Basic Geometry");
    if (!window) {
        fprintf(stderr, "ERROR: could not open window with GLFW3\n");
        glfwTerminate();
        return 1;
    } else {
        printf("OpenGL window successfully created\n");
    }

	// Create geometry buffers
    build_geometry();
    
    // Load shaders
	ShaderInfo simple_shaders[] = { {GL_VERTEX_SHADER, simple_vertex_shader},{GL_FRAGMENT_SHADER, simple_frag_shader},{GL_NONE, NULL} };
	simple_program = LoadShaders(simple_shaders);
	
	// Associate shader variables
	simple_vPos = glGetAttribLocation(simple_program, "vPosition");

    // Start loop
    while ( !glfwWindowShouldClose( window ) ) {
        // Draw graphics
        display();
        // Update other events like input handling
        glfwPollEvents();
        // Swap buffer onto screen
        glfwSwapBuffers( window );
    }

    // Close window
    glfwTerminate();
    return 0;
}


void display( )
{
	// TODO: Clear window

	// TODO: Render objects

	// TODO: Flush pipeline

}

void render_scene( ) {
	// TODO: Select shader program and bind vertex array and buffer

	// TODO: Draw geometry

}

void build_geometry( )
{
	// TODO: Generate and bind vertex arrays

	// TODO: Define vertices (ensure proper orientation)
	
	// TODO: Generate and bind vertex buffers

	// TODO: Load vertex data into buffer
	
	// TODO: Store number of vertices

}

