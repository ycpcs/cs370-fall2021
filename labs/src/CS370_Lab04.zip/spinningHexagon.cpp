#include <stdio.h>
#include "../common/vgl.h"
#include "../common/utils.h"
#include "../common/vmath.h"

using namespace vmath;

// Vertex array and buffer names
enum VAO_IDs {Hexagon, NumVAOs};
enum Obj_Buffer_IDs {PosBuffer, IndexBuffer, NumObjBuffers};
enum Color_Buffer_IDs {RedHex, NumColorBuffers};

// Vertex array and buffer objects
GLuint VAOs[NumVAOs];
GLuint ObjBuffers[NumVAOs][NumObjBuffers];
GLuint ColorBuffers[NumColorBuffers];

// Number of indices in each object
GLint numIndices[NumVAOs];

// Number of component coordinates
GLint posCoords = 2;
GLint colCoords = 4;

// Shader variables
// Shader program reference
GLuint trans_program;
// Shader component references
GLuint trans_vPos;
GLuint trans_vCol;
GLuint trans_model_mat_loc;
// Shader source files
const char *trans_vertex_shader = "../trans.vert";
const char *trans_frag_shader = "../trans.frag";

// Global state variables
GLfloat hex_angle = 0.0;
GLfloat hex_x = 0.0;
GLfloat hex_y = 0.0;
GLfloat delta = 0.1;
GLdouble elTime = 0.0;
GLdouble rpm = 10.0;
GLint dir = 1;

void display( );
void render_scene( );
void build_geometry( );
void key_callback(GLFWwindow *window, int key, int scancode, int action, int mods);
void mouse_callback(GLFWwindow *window, int button, int action, int mods);

int main(int argc, char**argv)
{
	// Create OpenGL window
	GLFWwindow* window = CreateWindow("Transform Hexagon");
    if (!window) {
        fprintf(stderr, "ERROR: could not open window with GLFW3\n");
        glfwTerminate();
        return 1;
    } else {
        printf("OpenGL window successfully created\n");
    }

    // TODO: Register callbacks

    // TODO: Get initial time

	// Create geometry buffers
    build_geometry();
    
    // Load shaders and associate shader variables
	ShaderInfo trans_shaders[] = { {GL_VERTEX_SHADER, trans_vertex_shader},{GL_FRAGMENT_SHADER, trans_frag_shader},{GL_NONE, NULL} };
	trans_program = LoadShaders(trans_shaders);
	trans_vPos = glGetAttribLocation(trans_program, "vPosition");
    trans_vCol = glGetAttribLocation(trans_program, "vColor");
    trans_model_mat_loc = glGetUniformLocation(trans_program, "model_matrix");

	// Start loop
    while ( !glfwWindowShouldClose( window ) ) {
    	// Draw graphics
        display();
        // Update other events like input handling
        glfwPollEvents();
        //  TODO: Update angle based on time for fixed rpm

        // Swap buffer onto screen
        glfwSwapBuffers( window );
    }

    // Close window
    glfwTerminate();
    return 0;
}

void display( )
{
	// Clear window
	glClear(GL_COLOR_BUFFER_BIT);

    // Render objects
	render_scene();

	// Flush pipeline
	glFlush();
}

void render_scene( ) {
    // Declare transformation matrices
    mat4 model_matrix = mat4().identity();
    mat4 scale_matrix = mat4().identity();
    mat4 rot_matrix = mat4().identity();
    mat4 trans_matrix = mat4().identity();

    // Select shader program and bind vertex array and buffer
    glUseProgram(trans_program);
    glBindVertexArray(VAOs[Hexagon]);
    glBindBuffer(GL_ARRAY_BUFFER, ObjBuffers[Hexagon][PosBuffer]);
    glVertexAttribPointer(trans_vPos, posCoords, GL_FLOAT, GL_FALSE, 0, NULL);
    glEnableVertexAttribArray(trans_vPos);

    // Draw hexagon
    // TODO: Set translation matrix

    // TODO: Set rotation matrix

    scale_matrix = scale(0.5f, 0.5f, 1.0f);
    model_matrix = trans_matrix*rot_matrix*scale_matrix;
    glUniformMatrix4fv(trans_model_mat_loc, 1, GL_FALSE, model_matrix);
    glBindBuffer(GL_ARRAY_BUFFER, ColorBuffers[RedHex]);
    glVertexAttribPointer(trans_vCol, colCoords, GL_FLOAT, GL_FALSE, 0, NULL);
    glEnableVertexAttribArray(trans_vCol);
    glDrawElements(GL_TRIANGLES, numIndices[Hexagon], GL_UNSIGNED_SHORT, NULL);
}

void build_geometry( )
{
    // Generate and bind vertex arrays
	glGenVertexArrays(NumVAOs, VAOs);
	glBindVertexArray(VAOs[Hexagon]);

    // Define vertices (no particular orientation)
	GLfloat vertices[][2] = {
		{1.0f, 0.0f},
		{0.5f, 0.866f},
		{-0.5f, 0.866f},
		{-1.0f, 0.0f},
		{-0.5f, -0.866f},
		{0.5f, -0.866f}
	};

	// Define red color array
	GLfloat red[][4] = {
		{1.0f, 0.0f, 0.0f, 1.0f},
		{1.0f, 0.0f, 0.0f, 1.0f},
		{1.0f, 0.0f, 0.0f, 1.0f},
		{1.0f, 0.0f, 0.0f, 1.0f},
		{1.0f, 0.0f, 0.0f, 1.0f},
		{1.0f, 0.0f, 0.0f, 1.0f},
	};

    // Define face indices (ensure proper orientation)
	GLushort indices[] = {
	        0, 1, 2,
	        2, 3, 4,
	        4, 5, 0,
	        0, 2, 4
	};

	// Set numIndices
	numIndices[Hexagon] = 12;

    // Generate vertex buffers
	glGenBuffers(NumObjBuffers, ObjBuffers[Hexagon]);
	glGenBuffers(NumColorBuffers, ColorBuffers);

	// Bind vertex positions
	glBindBuffer(GL_ARRAY_BUFFER, ObjBuffers[Hexagon][PosBuffer]);
	glBufferData(GL_ARRAY_BUFFER, sizeof(vertices), vertices, GL_STATIC_DRAW);

	// Bind red color
	glBindBuffer(GL_ARRAY_BUFFER, ColorBuffers[RedHex]);
	glBufferData(GL_ARRAY_BUFFER, sizeof(red), red, GL_STATIC_DRAW);

    // Bind hexagon indices
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, ObjBuffers[Hexagon][IndexBuffer]);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indices), indices, GL_STATIC_DRAW);
}

void key_callback(GLFWwindow *window, int key, int scancode, int action, int mods) {
    // Esc closes window
    if (key == GLFW_KEY_ESCAPE) {
        glfwSetWindowShouldClose(window, true);
    }

    // TODO: Move hexagon with arrow keys

}

void mouse_callback(GLFWwindow *window, int button, int action, int mods){
    // TODO: Flip spin direction with mouse click

}

